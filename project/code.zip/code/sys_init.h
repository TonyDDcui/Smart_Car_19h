/*
 * sys_init.h
 *
 *  Created on: 2024��3��12��
 *      Author: CuiZheXiao
 */

#ifndef INCLUDE_SYS_INIT_H_
#define INCLUDE_SYS_INIT_H_

#include "main.h"

extern uint8 camera_init_finish_flag;

void sys_init_set(void);

#endif /* INCLUDE_SYS_INIT_H_ */
